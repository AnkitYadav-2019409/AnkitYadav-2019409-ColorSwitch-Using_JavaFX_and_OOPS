package sample;


import javafx.scene.paint.Color;

public interface Colors {
            Color[] colors = new Color[]{Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW};
}
